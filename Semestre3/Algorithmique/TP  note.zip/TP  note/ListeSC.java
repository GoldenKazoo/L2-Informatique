/**
 * Classe ListeSC:
 * implémentation d'une liste simplement chaînée de caractères
 * 
 * ATTENTION: vous ne devez pas modifier ce fichier.
 */
public class ListeSC
{
    public MaillonSC tete;
    
    // Constructeur pour une liste vide
    public ListeSC() {
        this.tete = null;
    }
}
