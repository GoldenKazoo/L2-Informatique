
public class Meat extends Food
{
    public Meat(String name, boolean vegetable, boolean meat)
    {
        super(name, vegetable, meat);
    }
}
