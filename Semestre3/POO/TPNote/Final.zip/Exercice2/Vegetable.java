
public class Vegetable extends Food
{

    public Vegetable(String name, boolean vegetable, boolean meat)
    {
        super(name, vegetable, meat);
    }

}
