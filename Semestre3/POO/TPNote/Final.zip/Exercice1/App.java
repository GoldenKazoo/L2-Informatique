public class App {

        public static void main(String[] args)
    {
        Toy jouet1 = new Toy();
        Basket basket = new Basket();
        basket.add(jouet1);
    }
    
}
