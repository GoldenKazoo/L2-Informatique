public class Toy
{
    int     price;
    int[]   color = new int [3];
}
